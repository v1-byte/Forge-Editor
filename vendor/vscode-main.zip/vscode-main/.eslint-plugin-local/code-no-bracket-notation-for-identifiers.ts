/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import * as eslint from 'eslint';
import type * as ESTree from 'estree';
import { TSESTree } from '@typescript-eslint/utils';
import * as ts from 'typescript';

/**
 * Prefer dot notation for identifier properties, including TypeScript private members.
 * Allow bracket notation for environment-variable names accessed directly through process.env.
 */
export default new class NoBracketNotationForIdentifiers implements eslint.Rule.RuleModule {

	readonly meta: eslint.Rule.RuleMetaData = {
		type: 'problem',
		docs: {
			description: 'Disallow bracket notation for identifier properties except on process.env'
		},
		messages: {
			noBracketNotation: 'Use dot notation instead of bracket notation for property \'{{property}}\'.'
		},
		schema: [],
		fixable: 'code'
	};

	create(context: eslint.Rule.RuleContext): eslint.Rule.RuleListener {

		/**
		 * Check if a string is a valid JavaScript identifier
		 */
		function isValidIdentifier(str: string): boolean {
			const scanner = ts.createScanner(ts.ScriptTarget.Latest, false, ts.LanguageVariant.Standard, str);
			const token = scanner.scan();
			const isIdentifierName = token === ts.SyntaxKind.Identifier
				|| (token >= ts.SyntaxKind.FirstKeyword && token <= ts.SyntaxKind.LastKeyword);
			return isIdentifierName && scanner.getTokenText() === str && scanner.scan() === ts.SyntaxKind.EndOfFileToken;
		}

		return {
			MemberExpression(node: ESTree.MemberExpression) {
				const memberExpr = node as TSESTree.MemberExpression;

				// Only check computed member expressions (bracket notation)
				if (!memberExpr.computed) {
					return;
				}

				// Only check string literals in brackets
				if (memberExpr.property.type !== 'Literal' || typeof memberExpr.property.value !== 'string') {
					return;
				}

				// Preserve escaped property names instead of replacing their authored representation.
				if (memberExpr.property.raw.includes('\\')) {
					return;
				}

				const receiver = memberExpr.object;
				if (receiver.type === 'MemberExpression' && !receiver.computed
					&& receiver.object.type === 'Identifier' && receiver.object.name === 'process'
					&& receiver.property.type === 'Identifier' && receiver.property.name === 'env') {
					return;
				}

				const propertyName = memberExpr.property.value;

				// If it's a valid identifier, report it
				if (isValidIdentifier(propertyName)) {
					context.report({
						node: memberExpr.property,
						messageId: 'noBracketNotation',
						data: {
							property: propertyName
						},
						fix(fixer) {
							const property = memberExpr.property as unknown as eslint.Rule.Node;
							const leftBracket = context.sourceCode.getTokenBefore(property);
							const rightBracket = context.sourceCode.getTokenAfter(property);
							if (leftBracket?.value !== '[' || rightBracket?.value !== ']') {
								return null;
							}
							const hasComments = context.sourceCode
								.getTokensBetween(leftBracket, rightBracket, { includeComments: true })
								.some(token => token.type === 'Block' || token.type === 'Line');
							if (hasComments) {
								return null;
							}

							const bracketFix = fixer.replaceTextRange(
								[leftBracket.range[0], rightBracket.range[1]],
								`${memberExpr.optional ? '' : '.'}${propertyName}`
							);
							if (memberExpr.object.type === 'Literal' && typeof memberExpr.object.value === 'number') {
								const object = memberExpr.object as unknown as eslint.Rule.Node;
								return [
									fixer.insertTextBefore(object, '('),
									fixer.insertTextAfter(object, ')'),
									bracketFix
								];
							}

							return bracketFix;
						}
					});
				}
			}
		};
	}
};
