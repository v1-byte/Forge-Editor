---
name: agent-host-logs
description: 'Analyze Agent Host debug log exports. Use when given an ah-logs or ahp-logs zip/folder, an Export Agent Host Debug Logs bundle, events.jsonl, AHP JSONL transport logs, Agent Host.log, remote-agenthost.log, or copilot-logs.'
---

# Agent Host Debug Logs

Use this skill to orient to bundles produced by `Developer: Export Agent Host Debug Logs...`. These are different from the normal timestamped Code OSS log directory.

Treat the bundle as sensitive: it can contain tokens, prompts, file contents, terminal output, paths, and settings. Keep analysis local and avoid quoting secrets or unrelated user content. Timestamps, event names, IDs, status values, and general property values are fine.

## Open the Bundle

The export name usually starts with `ah-logs` and may be a zip or an already-unpacked folder. For a zip, use the bundled extractor:

```bash
python3 .github/skills/agent-host-logs/scripts/extract.py "<archive>.zip"
```

The final line gives the temporary extraction path. Work from that folder and delete only that exact folder when finished.

Desktop ZIP exports keep host-owned logs compressed inside `host-logs.zip`, alongside the client-owned logs and sidecars. If that entry is present, run the same extractor on `<extracted-folder>/host-logs.zip` and inspect both extraction folders. The host archive contains `events.jsonl`, provider logs, Agent Host process logs, and Mission Control transport logs. Folder exports place these files directly in the export folder.

Exports remain cancellable while collecting and saving logs. The final destination swap disables Cancel until it finishes or restores the previous export. If restoration fails, the error identifies the backup holding the previous export. Partial host-log collection or copying produces a warning alongside the saved client logs.

Files are collected best-effort, so a valid bundle may contain only some of these:

```text
events.jsonl
usage.jsonl
customizations.json
agenthost.log
agenthost.1.log
agenthost-server.log
vscode-logs/Window/renderer.log
vscode-logs/Window/renderer.1.log
vscode-logs/Shared/sharedprocess.log
ahp/*.jsonl
ahp/mission-control/*.jsonl
copilot-logs/*.log
remote-agenthost.log
```

## What the Files Mean

The basic flow is:

```text
Window/client <-> AHP <-> Agent Host process <-> Copilot SDK
```

| Path | What it shows |
|---|---|
| `host-logs.zip` | Compressed host-owned portion of a desktop export. Extract it separately to access the host files described below. |
| `events.jsonl` | Persisted Copilot SDK events for the selected session: turns, messages, tools, permissions, hooks, skills, and subagents. It can cover a much longer period than the other logs. |
| `usage.jsonl` | Client-captured token/credit usage, one record per model call (`turnId`, model, input/output/cache tokens, cumulative `totalNanoAiu`). The SDK's `assistant.usage` event is ephemeral and never reaches `events.jsonl`, so this is the only per-call usage record. Present only when agent-host debug logging was on. |
| `customizations.json` | Snapshot of the skills/hooks/agents/MCP servers loaded for the session. The SDK's `session.*_loaded` events are ephemeral, so this is the only record of what was actually active. Present only when agent-host debug logging was on. |
| `ahp/*.jsonl` | AHP traffic for a client connection. `_ahpLog.dir` is `c2s` or `s2c`; `_ahpLog.ts` is when the logging process handled the message, not when it was sent. Use this to see requests, responses, subscriptions, actions, notifications, and client-visible ordering. |
| `ahp/mission-control/*.jsonl` | Host-side traffic for incoming Mission Control clients, including authentication failures before a session is selected. `_ahpLog.transport` is `mission-control`; `connectionId` combines the client ID and connection generation. Host exports include up to ten most recently modified files, including rotated segments, within the remaining 1,000-entry artifact budget, even for a session-specific export. These logs can contain traffic for other shared sessions. |
| `agenthost*.log` | Local or server Agent Host process behavior: startup, auth, sessions, provider events, tools, Git/worktrees, and host-side errors. Numbered files are older rotated segments. |
| `copilot-logs/*.log` | Copilot SDK process logs that mention the selected session ID. A process log may contain other sessions too. |
| `vscode-logs/Window/*` | Current and rotated files from the Window log group, including renderer/client behavior, network activity, views, and other window-owned logs. |
| `vscode-logs/Shared/*` | Current and rotated files from the Shared log group. Usually secondary evidence and often noisy. |
| `Agent Host (<name>).log` | Forwarded logs from a named remote Agent Host. |
| `remote-agenthost.log` | A directly downloaded remote `agenthost.log`, when available. |

## How to Start

1. List the files and note their sizes.
2. Identify the reported symptom, approximate time, local or remote host, and any known session, chat, turn, request, or tool ID.
3. Start with the file closest to the symptom:
   - Turn or provider behavior: `events.jsonl`
   - Token/credit usage or cost questions: `usage.jsonl`
   - Client/server state or ordering: `ahp/*.jsonl`
   - Host implementation failure: `agenthost*.log`
   - SDK behavior: `copilot-logs/*.log`
   - UI behavior: `vscode-logs/Window/renderer.log` and its rotated segments
4. Search by the known time or ID, then follow the same operation into the adjacent layer.

Useful correlation fields include the raw session ID, session/chat URI, `turnId`, `interactionId`, tool/request IDs, JSON-RPC request `id`, AHP `serverSeq`, and event `id`/`parentId`.

## Copilot Session Refresh Failures

At the default Info log level, `agenthost*.log` records the refresh operation, configuration and SDK session IDs, chat, turn, and first matching `reason`. Only the first matching trigger is reported, preserving the restart checks' short-circuit order. Structural reasons distinguish client tools, client plugins, and root MCP configuration without logging their contents.

Follow `Preparing SDK session` and the paired `SDK resumeSession started` / `settled` records by `attemptId`. Follow each attached SDK session's shutdown and disconnect records by `instanceId`, which distinguishes successive wrappers of the same SDK session. A `disconnect wait completed` record with `disconnectRpc=pending` and `shutdownReceived=true` means the shutdown notification unblocked the caller before the disconnect RPC settled. A later RPC completion or failure, including after `disposed=true`, is logged separately. Neither the notification nor the host-side wait alone proves that native cleanup finished; correlate these with the SDK process log before concluding there was a teardown/resume race.

## Important Tips

- `events.jsonl`, Copilot SDK logs, and AHP timestamps are normally UTC. The plain `.log` files may use local machine time; remote logs may use another timezone.
- An AHP log is connection-scoped and can contain multiple sessions. A Copilot SDK process log can also contain multiple sessions.
- Mission Control lane traffic is logged independently of the desktop client's `chat.agentHost.ahpJsonlLoggingEnabled` setting. Authentication request tokens are redacted, but other session content remains sensitive.
- Mission Control history is retained across connection generations within ten files and 750 MiB per host log directory. A directory export keeps client-local fallback candidates until the host copy succeeds; if the host artifact is unavailable, Mission Control logs appear under `ahp/` instead.
- AHP files rotate as `.jsonl`, `.1.jsonl`, `.2.jsonl`, and so on. Use `_ahpLog.ts` to reconstruct order.
- A `subscribe` result can contain a full snapshot; its contents did not necessarily change at subscription time.
- `_ahpLog.truncated: true` means large values were omitted from that log record.
- Warning or error severity alone does not prove causality. Look for the matching failed response, missing completion, or user-visible consequence.
- Missing files are normal because export collection is best-effort.
