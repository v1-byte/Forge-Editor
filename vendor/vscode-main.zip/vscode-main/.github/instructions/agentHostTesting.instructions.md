---
description: Architecture documentation for VS Code AI Customization view. Use when working in `src/vs/workbench/contrib/chat/browser/aiCustomization`
applyTo: 'src/vs/platform/agentHost/**'
---

# Agent Host

The agent host communicates via the Agent Host Protocol. The specification for this lives in a directory `../agent-host-protocol` as a sibling of the VS Code directory.

If this directory doesn't exist, you should use the "ask questions" tool to ask the user if they want to clone `git@github.com:microsoft/agent-host-protocol.git` to that directory. After doing so, you should also prompt the user to add `file:///<path/to/agent-host-protocol>/plugins/copilot-plugin` as a plugin in their `chat.pluginLocations` settings.

## Overall Protocol

The sessions process is a portable, standalone server that multiple clients can connect to. Clients see a synchronized view of sessions and can send commands that are reflected back as state-changing actions. The protocol is designed around four requirements:

1. **Synchronized multi-client state** — an immutable, redux-like state tree mutated exclusively by actions flowing through pure reducers. While there is the option to implement functionality via imperative commands, we ALWAYS prefer to model features as pure state and actions.
2. **Lazy loading** — clients subscribe to state by URI and load data on demand. The session list is fetched imperatively. Large content (images, long tool outputs) is stored by reference and fetched separately.
3. **Write-ahead with reconciliation** — clients optimistically apply their own actions locally, then reconcile when the server echoes them back alongside any concurrent actions from other clients or the server itself.
4. **Forward-compatible versioning** — newer clients can connect to older servers. A single protocol version number maps to a capabilities object; clients check capabilities before using features.

See the agent host protocol documentation for more details.

## Service Construction

Read `src/vs/platform/agentHost/node/serviceBootstrapping.md` before adding or moving a node Agent Host service. It is the canonical guide for service placement, static constructor arguments, activation, test overrides, and disposal ownership.

## Protocol Metadata

Put new readers for namespaced protocol `_meta` slots under `common/meta`. Readers must validate every value they return and expose typed data; callers should pass the parent protocol object rather than inspecting `_meta` fields directly. Existing unnamespaced and legacy readers live elsewhere and should be migrated separately when touched. Use type guards for dynamic properties; do not bypass type narrowing or lint rules with `Reflect.get`.

Host-specific parsers and writers live under `common/meta/vscode` and `common/meta/copilotd`. Feature code imports only top-level `common/meta` helpers, which own source selection and domain conversion; ESLint enforces this boundary for value and type imports.

## Tools, Prompt Text and Reminders

Tools the model can see are input tokens on every request. New tools are deferred by default, and the eager set is a reviewed budget pinned by tests. Prompt text and reminders have fixed homes based on how they affect the prompt cache. Follow §9 of `src/vs/platform/agentHost/AGENTS.md` when adding a tool, bumping the Copilot SDK, or adding text that reaches the model.

When `copilotBuiltinToolAllowlist.integrationTest.ts` reports a new runtime built-in, first check whether it renames an allow-listed tool the runtime no longer registers. For a rename, replace the old name with the new one in the allow-list and in `expectedModelFacingToolNames`, and add it to the tool display mapping, so the capability stays on. Add any other new built-in to `KNOWN_LEFT_OFF` in that test with a reason. Never add a new tool to `COPILOT_ENABLED_BUILTIN_TOOL_NAMES` or to a reviewed eager list just to make a test pass; adopting a new tool is a decision for the tool budget owners that `.github/CODENOTIFY` lists for those files.

## End to End Testing

You can run `node ./scripts/code-agent-host.js` to start an agent host. If you pass `--enable-mock-agent`, then the `ScriptedMockAgent` will be used.

By default this will listen on `ws://127.0.0.1:8081`. You can then use the `ahp-websocket` client, when available, to connect to and communicate with it.

## Learnings

- Provider-owned session configuration inheritance must be selected by the owning `IAgent`; `AgentService` only orchestrates transfer and must not encode provider-specific configuration keys.
