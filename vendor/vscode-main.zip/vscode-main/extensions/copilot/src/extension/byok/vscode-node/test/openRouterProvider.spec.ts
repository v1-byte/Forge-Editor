/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { describe, expect, it, vi } from 'vitest';
import { ModelSupportedEndpoint } from '../../../../platform/endpoint/common/endpointProvider';
import { IFetcherService } from '../../../../platform/networking/common/fetcherService';
import { createFakeResponse } from '../../../../platform/test/node/fetcher';
import { CancellationToken } from '../../../../util/vs/base/common/cancellation';
import { BYOKModelCapabilities } from '../../common/byokProvider';
import { OpenRouterEndpoint, OpenRouterLMProvider } from '../openRouterProvider';

/**
 * Tests for issue #324671:
 * OpenRouter BYOK previously derived the context window from `top_provider.context_length`,
 * which is the window of the highest-ranked provider — NOT the model's real capability
 * (`context_length`). For multi-provider models this could be off by 32×. These tests
 * verify the fix: the model-level `context_length` is preferred, with `top_provider`
 * used only as a fallback.
 */

/** Exposes the protected `resolveModelCapabilities` for focused testing. */
class TestableOpenRouterLMProvider extends OpenRouterLMProvider {
	public resolveCapabilities(modelData: unknown): BYOKModelCapabilities | undefined {
		return this.resolveModelCapabilities(modelData);
	}
}

function createProvider(fetch: IFetcherService['fetch'] = vi.fn(), createInstance = vi.fn().mockReturnValue({})): TestableOpenRouterLMProvider {
	const logService = {
		trace: vi.fn(), debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(),
		show: vi.fn(), createSubLogger: vi.fn(), withExtraTarget: vi.fn(),
	};
	logService.createSubLogger.mockReturnValue(logService);
	logService.withExtraTarget.mockReturnValue(logService);

	return new TestableOpenRouterLMProvider(
		{ getAPIKey: vi.fn().mockResolvedValue(undefined), storeAPIKey: vi.fn(), deleteAPIKey: vi.fn() } as any,
		{ fetch } as any,
		logService as any,
		{ createInstance } as any,
		{ isConfigured: vi.fn().mockReturnValue(false), getConfig: vi.fn(), setConfig: vi.fn() } as any,
		{} as any,
	);
}

describe('OpenRouterLMProvider model discovery', () => {
	it('requests tool-capable models and preserves returned alias IDs and capabilities', async () => {
		const modelData = [
			{ id: '~anthropic/claude-fable-latest', name: 'Anthropic: Claude Fable Latest', supported_parameters: ['tools', 'reasoning'] },
			{ id: '~google/gemini-flash-latest', name: 'Google: Gemini Flash Latest', supported_parameters: ['tools'] },
			{ id: 'openai/gpt-chat-latest', name: 'OpenAI: GPT Chat Latest', supported_parameters: ['tools'] },
		].map(model => ({
			...model,
			context_length: 200000,
			top_provider: { context_length: 200000, max_completion_tokens: 16000 },
		}));
		const fetch = vi.fn<IFetcherService['fetch']>().mockImplementation(async () => createFakeResponse(200, { data: modelData }));
		const provider = createProvider(fetch);

		const models = await provider.provideLanguageModelChatInformation({ silent: false }, CancellationToken.None);

		expect({
			urls: fetch.mock.calls.map(([url]) => url),
			models: models.map(model => ({ id: model.id, name: model.name, toolCalling: model.capabilities.toolCalling })),
		}).toEqual({
			urls: ['https://openrouter.ai/api/v1/models?supported_parameters=tools'],
			models: [
				{ id: '~anthropic/claude-fable-latest', name: 'Anthropic: Claude Fable Latest', toolCalling: true },
				{ id: '~google/gemini-flash-latest', name: 'Google: Gemini Flash Latest', toolCalling: true },
				{ id: 'openai/gpt-chat-latest', name: 'OpenAI: GPT Chat Latest', toolCalling: true },
			],
		});
	});

	it.each([
		{ id: 'anthropic/claude-fable-5.1', path: 'messages', supportedEndpoints: [ModelSupportedEndpoint.Messages] },
		{ id: '~anthropic/claude-fable-latest', path: 'messages', supportedEndpoints: [ModelSupportedEndpoint.Messages] },
		{ id: 'example/anthropic/claude-fable-latest', path: 'messages', supportedEndpoints: [ModelSupportedEndpoint.Messages] },
		{ id: 'openai/gpt-chat-latest', path: 'chat/completions', supportedEndpoints: undefined },
		{ id: '~google/gemini-flash-latest', path: 'chat/completions', supportedEndpoints: undefined },
	])('routes $id without rewriting the model ID', async ({ id, path, supportedEndpoints }) => {
		const fetch = vi.fn<IFetcherService['fetch']>().mockImplementation(async () => createFakeResponse(200, {
			data: [{
				id,
				name: id,
				supported_parameters: ['tools'],
				context_length: 200000,
				top_provider: { context_length: 200000 },
			}],
		}));
		const createInstance = vi.fn().mockReturnValue({});
		const provider = createProvider(fetch, createInstance);

		await provider.provideLanguageModelChatInformation({ silent: false }, CancellationToken.None);

		expect(createInstance).toHaveBeenLastCalledWith(
			OpenRouterEndpoint,
			expect.objectContaining({ id, supported_endpoints: supportedEndpoints }),
			'',
			`https://openrouter.ai/api/v1/${path}`,
		);
	});
});

describe('OpenRouterLMProvider context window (issue #324671)', () => {
	it('derives maxInputTokens from the model-level context_length, not top_provider', () => {
		const provider = createProvider();

		// `xiaomi/mimo-v2.5`: the model supports 1M tokens, but the highest-ranked
		// provider only serves 32K. The Xiaomi provider (1M) is not the top provider.
		const caps = provider.resolveCapabilities({
			id: 'xiaomi/mimo-v2.5',
			name: 'MiMo v2.5',
			supported_parameters: ['tools'],
			architecture: { input_modalities: ['text'] },
			context_length: 1048576,            // actual model capability (1M)
			top_provider: { context_length: 32000 }, // highest-ranked provider (32K)
		});

		// Uses the real 1M window minus the default 16K output reserve.
		expect(caps?.maxInputTokens).toBe(1048576 - 16000);
		expect(caps?.maxOutputTokens).toBe(16000);
	});

	it('honors top_provider.max_completion_tokens as the output budget', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'some/reasoning-model',
			name: 'Reasoning Model',
			supported_parameters: ['tools'],
			context_length: 200000,
			top_provider: { context_length: 200000, max_completion_tokens: 64000 },
		});

		expect(caps?.maxOutputTokens).toBe(64000);
		expect(caps?.maxInputTokens).toBe(200000 - 64000);
	});

	it('falls back to top_provider.context_length when the model omits context_length', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'legacy/model',
			name: 'Legacy Model',
			supported_parameters: ['tools'],
			top_provider: { context_length: 128000 },
		});

		expect(caps?.maxInputTokens).toBe(128000 - 16000);
	});

	it('clamps the output reserve so a small-context model keeps a positive prompt budget', () => {
		const provider = createProvider();

		// An 8K model whose provider reports a 16K completion budget larger than the
		// window. Without clamping, maxInputTokens would go negative (8000 - 16000).
		const caps = provider.resolveCapabilities({
			id: 'tiny/model',
			name: 'Tiny Model',
			supported_parameters: ['tools'],
			context_length: 8000,
			top_provider: { context_length: 8000, max_completion_tokens: 16000 },
		});

		// Reserve is capped at half the window, so the prompt budget stays positive.
		expect(caps?.maxOutputTokens).toBe(4000);
		expect(caps?.maxInputTokens).toBe(4000);
	});
});

describe('OpenRouterLMProvider reasoning effort (issue #335272)', () => {
	it('uses the model-declared supported_efforts instead of the hard-coded list', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'openai/gpt-5.6-luna',
			name: 'GPT-5.6 Luna',
			supported_parameters: ['reasoning_effort', 'tools'],
			architecture: { input_modalities: ['text'] },
			context_length: 200000,
			top_provider: { context_length: 200000 },
			reasoning: {
				supported_efforts: ['low', 'medium', 'high', 'xhigh'],
				default_effort: 'high',
			},
		});

		expect(caps?.supportsReasoningEffort).toEqual(['low', 'medium', 'high', 'xhigh']);
	});

	it('falls back to the default effort list when reasoning.supported_efforts is omitted', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'openai/gpt-5',
			name: 'GPT-5',
			supported_parameters: ['reasoning'],
			architecture: { input_modalities: ['text'] },
			context_length: 200000,
			top_provider: { context_length: 200000 },
			reasoning: {
				default_effort: 'low',
			},
		});

		expect(caps?.defaultReasoningEffort).toBe('low');
		expect(caps?.supportsReasoningEffort).toEqual(['low', 'medium', 'high']);
	});

	it('propagates the model-declared default_effort', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'openai/gpt-5.6-sol',
			name: 'GPT-5.6 Sol',
			supported_parameters: ['reasoning_effort', 'tools'],
			architecture: { input_modalities: ['text'] },
			context_length: 200000,
			top_provider: { context_length: 200000 },
			reasoning: {
				supported_efforts: ['minimal', 'low', 'medium', 'high'],
				default_effort: 'medium',
			},
		});

		expect(caps?.defaultReasoningEffort).toBe('medium');
		expect(caps?.supportsReasoningEffort).toEqual(['minimal', 'low', 'medium', 'high']);
	});

	it('leaves defaultReasoningEffort unset when the model reports no default_effort', () => {
		const provider = createProvider();

		const caps = provider.resolveCapabilities({
			id: 'openai/gpt-5',
			name: 'GPT-5',
			supported_parameters: ['reasoning_effort'],
			architecture: { input_modalities: ['text'] },
			context_length: 200000,
			top_provider: { context_length: 200000 },
			reasoning: {
				supported_efforts: ['low', 'medium', 'high'],
			},
		});

		expect(caps?.defaultReasoningEffort).toBeUndefined();
	});
});
