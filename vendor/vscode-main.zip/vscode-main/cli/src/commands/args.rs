/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

use std::{fmt, path::PathBuf};

use crate::{constants, log, options, tunnels::code_server::CodeServerArgs};
use clap::{Args, Parser, Subcommand, ValueEnum};
use const_format::concatcp;

const CLI_NAME: &str = concatcp!(constants::PRODUCT_NAME_LONG, " CLI");
const HELP_COMMANDS: &str = concatcp!(
	"Usage: ",
	constants::APPLICATION_NAME,
	" [options][paths...]

To read output from another program, append '-' (e.g. 'echo Hello World | {name} -')"
);

const STANDALONE_TEMPLATE: &str = concatcp!(
	CLI_NAME,
	" Standalone - {version}

",
	HELP_COMMANDS,
	"
Running editor commands requires installing ",
	constants::QUALITYLESS_PRODUCT_NAME,
	", and may differ slightly.

{all-args}"
);
const INTEGRATED_TEMPLATE: &str = concatcp!(
	CLI_NAME,
	" - {version}

",
	HELP_COMMANDS,
	"

{all-args}"
);

const COMMIT_IN_VERSION: &str = match constants::VSCODE_CLI_COMMIT {
	Some(c) => c,
	None => "unknown",
};
const NUMBER_IN_VERSION: &str = match constants::VSCODE_CLI_VERSION {
	Some(c) => c,
	None => "dev",
};
const VERSION: &str = concatcp!(NUMBER_IN_VERSION, " (commit ", COMMIT_IN_VERSION, ")");

#[derive(Parser, Debug, Default)]
#[clap(
   help_template = INTEGRATED_TEMPLATE,
   long_about = None,
	 name = constants::APPLICATION_NAME,
   version = VERSION,
 )]
pub struct IntegratedCli {
	#[clap(flatten)]
	pub core: CliCore,
}

/// Common CLI shared between integrated and standalone interfaces.
#[derive(Args, Debug, Default, Clone)]
pub struct CliCore {
	/// One or more files, folders, or URIs to open.
	#[clap(name = "paths")]
	pub open_paths: Vec<String>,

	#[clap(flatten, next_help_heading = Some("EDITOR OPTIONS"))]
	pub editor_options: EditorOptions,

	#[clap(flatten, next_help_heading = Some("EDITOR TROUBLESHOOTING"))]
	pub troubleshooting: EditorTroubleshooting,

	#[clap(flatten, next_help_heading = Some("GLOBAL OPTIONS"))]
	pub global_options: GlobalOptions,

	#[clap(subcommand)]
	pub subcommand: Option<Commands>,
}

#[derive(Parser, Debug, Default)]
#[clap(
   help_template = STANDALONE_TEMPLATE,
   long_about = None,
   version = VERSION,
	 name = constants::APPLICATION_NAME,
 )]
pub struct StandaloneCli {
	#[clap(flatten)]
	pub core: CliCore,

	#[clap(subcommand)]
	pub subcommand: Option<StandaloneCommands>,
}

pub enum AnyCli {
	Integrated(IntegratedCli),
	Standalone(StandaloneCli),
}

impl AnyCli {
	pub fn core(&self) -> &CliCore {
		match self {
			AnyCli::Integrated(cli) => &cli.core,
			AnyCli::Standalone(cli) => &cli.core,
		}
	}
}

impl CliCore {
	pub fn get_base_code_args(&self) -> Vec<String> {
		let mut args = self.open_paths.clone();
		self.editor_options.add_code_args(&mut args);
		self.troubleshooting.add_code_args(&mut args);
		self.global_options.add_code_args(&mut args);
		args
	}
}

impl<'a> From<&'a CliCore> for CodeServerArgs {
	fn from(cli: &'a CliCore) -> Self {
		let mut args = CodeServerArgs {
			log: cli.global_options.log,
			accept_server_license_terms: true,
			..Default::default()
		};

		args.log = cli.global_options.log;
		args.accept_server_license_terms = true;

		if cli.global_options.verbose {
			args.verbose = true;
		}

		if cli.global_options.disable_telemetry {
			args.telemetry_level = Some(options::TelemetryLevel::Off);
		} else if cli.global_options.telemetry_level.is_some() {
			args.telemetry_level = cli.global_options.telemetry_level;
		}

		args
	}
}

#[derive(Subcommand, Debug, Clone)]
pub enum StandaloneCommands {
	/// Updates the CLI.
	Update(StandaloneUpdateArgs),
}

#[derive(Args, Debug, Clone)]
pub struct StandaloneUpdateArgs {
	/// Only check for updates, without actually updating the CLI.
	#[clap(long)]
	pub check: bool,
}

#[derive(Subcommand, Debug, Clone)]

pub enum Commands {
	/// Create a tunnel that's accessible on vscode.dev from anywhere.
	/// Run `code tunnel --help` for more usage info.
	Tunnel(TunnelArgs),

	/// Manage editor extensions.
	#[clap(name = "ext")]
	Extension(ExtensionArgs),

	/// Print process usage and diagnostics information.
	Status,

	/// Changes the version of the editor you're using.
	Version(VersionArgs),

	/// Runs a local web version of VS Code.
	#[clap(about = concatcp!("Runs a local web version of ", constants::PRODUCT_NAME_LONG))]
	ServeWeb(ServeWebArgs),

	/// Runs the control server on process stdin/stdout
	#[clap(hide = true)]
	CommandShell(CommandShellArgs),

	/// Manage agent host sessions.
	#[clap(name = "agent")]
	Agent(Box<AgentArgs>),
}

#[derive(Args, Debug, Clone)]
pub struct ServeWebArgs {
	/// Host to listen on, defaults to 'localhost'
	#[clap(long)]
	pub host: Option<String>,
	// The path to a socket file for the server to listen to.
	#[clap(long)]
	pub socket_path: Option<String>,
	/// Port to listen on. If 0 is passed a random free port is picked.
	#[clap(long, default_value_t = 8000)]
	pub port: u16,
	/// A secret that must be included with all requests.
	#[clap(long)]
	pub connection_token: Option<String>,
	/// A file containing a secret that must be included with all requests.
	#[clap(long)]
	pub connection_token_file: Option<String>,
	/// Run without a connection token. Only use this if the connection is secured by other means.
	#[clap(long)]
	pub without_connection_token: bool,
	/// If set, the user accepts the server license terms and the server will be started without a user prompt.
	#[clap(long)]
	pub accept_server_license_terms: bool,
	/// Specifies the path under which the web UI and the code server is provided.
	#[clap(long)]
	pub server_base_path: Option<String>,
	/// Specifies the directory that server data is kept in.
	#[clap(long)]
	pub server_data_dir: Option<String>,
	/// The workspace folder to open when no input is specified in the browser URL.
	#[clap(long)]
	pub default_folder: Option<String>,
	/// The workspace to open when no input is specified in the browser URL.
	#[clap(long)]
	pub default_workspace: Option<String>,
	/// Disables telemetry.
	#[clap(long)]
	pub disable_telemetry: bool,
	/// Use a specific commit SHA for the client.
	#[clap(long)]
	pub commit_id: Option<String>,
}

#[derive(Args, Debug, Clone, Default)]
pub struct AgentHostArgs {
	/// Host the agent host should bind on. Defaults to 'localhost'. Pass
	/// `0.0.0.0` to expose the agent host on all interfaces (paired with
	/// a connection token unless `--without-connection-token` is set).
	#[clap(long)]
	pub host: Option<String>,
	/// Port the agent host should bind on. If 0 (the default) the OS
	/// picks a free ephemeral port; the chosen port is recorded in the
	/// shared agent-host endpoint registry.
	#[clap(long, default_value_t = 0)]
	pub port: u16,
	/// A secret that must be included with all requests.
	#[clap(long)]
	pub connection_token: Option<String>,
	/// A file containing a secret that must be included with all requests.
	#[clap(long)]
	pub connection_token_file: Option<String>,
	/// Run without a connection token. Only use this if the connection is secured by other means.
	#[clap(long)]
	pub without_connection_token: bool,
	/// Specifies the directory that server data is kept in.
	#[clap(long)]
	pub server_data_dir: Option<String>,

	/// Overrides the resolved user data directory used to home the local
	/// agent-host endpoint registry
	/// (`<user-data-dir>/agent-host/local-endpoint/entries/`, the directory of
	/// per-instance entry files editor windows also publish to). Defaults to
	/// the platform user data directory (honoring `VSCODE_PORTABLE` /
	/// `VSCODE_APPDATA` when set), matching the editor's own resolution rules.
	#[clap(long)]
	pub user_data_dir: Option<String>,

	/// Stop any agent host already running on this machine and start a
	/// fresh one. Without this flag, the command reuses an existing live
	/// supervisor when its configuration is compatible, and errors out
	/// when the requested `--host` / `--port` / `--connection-token`
	/// differ from what's already running.
	#[clap(long)]
	pub replace: bool,

	/// Always start a brand new standalone supervisor, even if one is
	/// already registered and would normally be reused. Unlike
	/// `--replace`, this never kills or removes any existing registry
	/// entry (editor or standalone) — the new supervisor simply
	/// publishes its own additional entry alongside whatever is already
	/// there. Useful for remote scenarios (e.g. "Start New Dedicated
	/// Agent Host") that must guarantee a fresh, independent instance
	/// regardless of what else is running.
	#[clap(long)]
	pub new_instance: bool,

	/// Run a newly started agent host supervisor in the foreground instead
	/// of detaching it, keeping its logs attached to this terminal and
	/// stopping it on Ctrl-C. Useful for debugging. An existing compatible
	/// supervisor is still reused, so combine this with `--replace` or
	/// `--new-instance` to guarantee a supervisor is actually started here.
	#[clap(long)]
	pub foreground: bool,

	/// Alias for `code tunnel`: expose remote editor and agent host access.
	#[clap(
		long,
		group = "remote_host",
		conflicts_with_all = [
			"host", "port", "connection_token", "connection_token_file",
			"without_connection_token", "replace", "new_instance", "foreground", "idle_timeout"
		]
	)]
	pub tunnel: bool,
	/// Register this agent host as a GitHub environment. Runs in the foreground.
	#[clap(
		long,
		group = "remote_host",
		conflicts_with_all = [
			"host", "port", "connection_token", "connection_token_file",
			"without_connection_token", "replace", "new_instance", "foreground", "idle_timeout",
			"random_name", "tunnel_id", "host_token", "cluster", "tunnel_name"
		]
	)]
	pub github_environment: bool,
	/// Grant access to a project directory. Repeat for multiple projects. Defaults to the current directory.
	#[clap(long, requires = "github_environment", conflicts_with = "tunnel")]
	pub github_environment_root: Vec<PathBuf>,
	/// Sets the machine name for the tunnel or GitHub environment.
	#[clap(long, requires = "remote_host")]
	pub name: Option<String>,
	/// Randomly name the machine for the tunnel.
	#[clap(long, requires = "tunnel")]
	pub random_name: bool,
	/// Accept the server license terms when starting a tunnel or GitHub environment.
	#[clap(long, requires = "remote_host")]
	pub accept_server_license_terms: bool,

	/// Automatically terminate this supervisor once no client has been
	/// connected for this many seconds. The idle timer starts once the
	/// supervisor is ready, is cancelled/paused for as long as at least
	/// one client is connected or the agent host server is running, and
	/// restarts from the full duration each time the last of those goes
	/// away. The server only stops itself after it has had no running
	/// agent sessions and no clients for a while, so in-progress sessions
	/// are never cut short. Unset (the default) means unlimited: a
	/// manually started local host never self-terminates.
	#[clap(long)]
	pub idle_timeout: Option<u64>,

	/// Optional details to connect to an existing tunnel.
	#[clap(flatten, next_help_heading = Some("ADVANCED TUNNEL OPTIONS"))]
	pub existing_tunnel: ExistingTunnelArgs,
}

impl From<AgentHostArgs> for TunnelServeArgs {
	fn from(args: AgentHostArgs) -> Self {
		Self {
			server_args: BaseServerArgs {
				server_data_dir: args.server_data_dir,
				..Default::default()
			},
			tunnel: args.existing_tunnel,
			name: args.name,
			random_name: args.random_name,
			user_data_dir: args.user_data_dir,
			accept_server_license_terms: args.accept_server_license_terms,
			..Default::default()
		}
	}
}

#[derive(Args, Debug, Clone)]
pub struct AgentArgs {
	#[clap(subcommand)]
	pub subcommand: Option<AgentSubcommand>,

	/// Agent host arguments used when no subcommand is given.
	#[clap(flatten)]
	pub host_args: AgentHostArgs,
}

#[derive(Subcommand, Debug, Clone)]
pub enum AgentSubcommand {
	/// Start an agent host server, with optional remote access.
	Host(AgentHostArgs),

	/// List active sessions on a running agent host.
	Ps(AgentPsArgs),

	/// Cancel the active turn of a session.
	Stop(AgentStopArgs),

	/// Forcefully kill the running agent host process tree.
	Kill(AgentKillArgs),

	/// Stream live session events.
	Logs(AgentLogsArgs),

	/// Print every live agent host endpoint as a single JSON document.
	/// Machine-readable: intended for consumption over an already
	/// authenticated transport (e.g. SSH), since the output includes each
	/// endpoint's connection token.
	Endpoints(AgentEndpointsArgs),

	/// Relay stdin/stdout to a single live agent host endpoint's raw
	/// socket/pipe or TCP connection, with no WebSocket interpretation and
	/// no banner output. Intended to be used as an SSH `ProxyCommand`-style
	/// bridge to reach `editor`-owned (socket/pipe) endpoints remotely.
	#[clap(hide = true)]
	Relay(AgentRelayArgs),
}

#[derive(Args, Debug, Clone)]
pub struct AgentEndpointsArgs {
	/// Overrides the resolved user data directory used to locate the
	/// shared agent host registry. Defaults to the platform user data
	/// directory, matching every other `code agent` subcommand.
	#[clap(long)]
	pub user_data_dir: Option<String>,
}

#[derive(Args, Debug, Clone)]
pub struct AgentRelayArgs {
	/// The `instanceId` of the live registry endpoint to relay to, as
	/// shown by `code agent endpoints` / `code agent ps`.
	pub instance_id: String,

	/// Overrides the resolved user data directory used to locate the
	/// shared agent host registry.
	#[clap(long)]
	pub user_data_dir: Option<String>,
}

/// Discovery/connection target shared by every agent-host command that
/// can either auto-discover a local instance or target one explicitly:
/// `code agent ps|stop|logs`. `--user-data-dir` scopes automatic
/// discovery to a specific registry (see
/// [`crate::commands::agent_discovery::discover_live_endpoints`]);
/// `--address`/`--tunnel` bypass discovery entirely and connect to
/// exactly one explicit target (see
/// [`crate::commands::agent::connect_explicit`]). Passing neither
/// `--address` nor `--tunnel` means "discover automatically", not
/// "connect nowhere" — every consumer of this struct must branch on that
/// itself.
#[derive(Args, Debug, Clone)]
pub struct AgentDiscoveryArgs {
	/// Directory containing the shared agent host registry used for automatic discovery.
	#[clap(long)]
	pub user_data_dir: Option<String>,

	/// WebSocket address of a running agent host (e.g. ws://127.0.0.1:1234?tkn=secret).
	/// If omitted, the CLI discovers a locally running agent host automatically.
	#[clap(long)]
	pub address: Option<String>,

	/// Connect via a named dev tunnel instead of the local address.
	#[clap(long)]
	pub tunnel: Option<String>,
}

#[derive(Args, Debug, Clone)]
pub struct AgentPsArgs {
	/// Discovery/connection target; see [`AgentDiscoveryArgs`].
	#[clap(flatten)]
	pub discovery: AgentDiscoveryArgs,

	/// Output results as JSON instead of a human-readable table.
	#[clap(long)]
	pub json: bool,

	/// Show all sessions, including idle and archived ones.
	#[clap(long, short)]
	pub all: bool,
}

#[derive(Args, Debug, Clone)]
pub struct AgentStopArgs {
	/// Session URI to cancel the active turn of (e.g. copilot:/<uuid>).
	pub session: String,

	/// Discovery/connection target; see [`AgentDiscoveryArgs`].
	#[clap(flatten)]
	pub discovery: AgentDiscoveryArgs,
}

#[derive(Args, Debug, Clone)]
pub struct AgentLogsArgs {
	/// Session URI to stream events for (e.g. copilot:/<uuid>).
	pub session: String,

	/// Discovery/connection target; see [`AgentDiscoveryArgs`].
	#[clap(flatten)]
	pub discovery: AgentDiscoveryArgs,
}

#[derive(Args, Debug, Clone)]
pub struct AgentKillArgs {
	/// Directory containing the shared agent host registry used for automatic discovery.
	#[clap(long)]
	pub user_data_dir: Option<String>,

	/// Instance ID of the standalone agent host to kill, as shown when
	/// multiple are running. Required to select non-interactively when
	/// more than one live standalone agent host is registered.
	#[clap(long)]
	pub instance_id: Option<String>,
}

#[derive(Args, Debug, Clone)]
pub struct CommandShellArgs {
	#[clap(flatten)]
	pub server_args: BaseServerArgs,

	/// Listen on a socket instead of stdin/stdout.
	#[clap(long)]
	pub on_socket: bool,
	/// Listen on a host/port instead of stdin/stdout.
	#[clap(long, num_args = 0..=2, default_missing_value = "0")]
	pub on_port: Vec<u16>,
	/// Listen on a host/port instead of stdin/stdout.
	#[clap[long]]
	pub on_host: Option<String>,
	/// Require the given token string to be given in the handshake.
	#[clap(long, env = "VSCODE_CLI_REQUIRE_TOKEN")]
	pub require_token: Option<String>,
	/// Optional parent process id. If provided, the server will be stopped when the process of the given pid no longer exists
	#[clap(long, hide = true)]
	pub parent_process_id: Option<String>,
}

#[derive(Args, Debug, Clone)]
pub struct ExtensionArgs {
	#[clap(subcommand)]
	pub subcommand: ExtensionSubcommand,

	#[clap(flatten)]
	pub desktop_code_options: DesktopCodeOptions,
}

impl ExtensionArgs {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		self.desktop_code_options.add_code_args(target);
		self.subcommand.add_code_args(target);
	}
}

#[derive(Subcommand, Debug, Clone)]
pub enum ExtensionSubcommand {
	/// List installed extensions.
	List(ListExtensionArgs),
	/// Install an extension.
	Install(InstallExtensionArgs),
	/// Uninstall an extension.
	Uninstall(UninstallExtensionArgs),
	/// Update the installed extensions.
	Update,
}

impl ExtensionSubcommand {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		match self {
			ExtensionSubcommand::List(args) => {
				target.push("--list-extensions".to_string());
				if args.show_versions {
					target.push("--show-versions".to_string());
				}
				if let Some(category) = &args.category {
					target.push(format!("--category={category}"));
				}
			}
			ExtensionSubcommand::Install(args) => {
				for id in args.id_or_path.iter() {
					target.push(format!("--install-extension={id}"));
				}
				if args.pre_release {
					target.push("--pre-release".to_string());
				}
				if args.donot_include_pack_and_dependencies {
					target.push("do-not-include-pack-dependencies".to_string());
				}
				if args.force {
					target.push("--force".to_string());
				}
			}
			ExtensionSubcommand::Uninstall(args) => {
				for id in args.id.iter() {
					target.push(format!("--uninstall-extension={id}"));
				}
			}
			ExtensionSubcommand::Update => {
				target.push("--update-extensions".to_string());
			}
		}
	}
}

#[derive(Args, Debug, Clone)]
pub struct ListExtensionArgs {
	/// Filters installed extensions by provided category, when using --list-extensions.
	#[clap(long, value_name = "category")]
	pub category: Option<String>,

	/// Show versions of installed extensions, when using --list-extensions.
	#[clap(long)]
	pub show_versions: bool,
}

#[derive(Args, Debug, Clone)]
pub struct InstallExtensionArgs {
	/// Either an extension id or a path to a VSIX. The identifier of an
	/// extension is '${publisher}.${name}'. Use '--force' argument to update
	/// to latest version. To install a specific version provide '@${version}'.
	/// For example: 'vscode.csharp@1.2.3'.
	#[clap(name = "ext-id | id")]
	pub id_or_path: Vec<String>,

	/// Installs the pre-release version of the extension
	#[clap(long)]
	pub pre_release: bool,

	/// Don't include installing pack and dependencies of the extension
	#[clap(long)]
	pub donot_include_pack_and_dependencies: bool,

	/// Update to the latest version of the extension if it's already installed.
	#[clap(long)]
	pub force: bool,
}

#[derive(Args, Debug, Clone)]
pub struct UninstallExtensionArgs {
	/// One or more extension identifiers to uninstall. The identifier of an
	/// extension is '${publisher}.${name}'. Use '--force' argument to update
	/// to latest version.
	#[clap(name = "ext-id")]
	pub id: Vec<String>,
}

#[derive(Args, Debug, Clone)]
pub struct VersionArgs {
	#[clap(subcommand)]
	pub subcommand: VersionSubcommand,
}

#[derive(Subcommand, Debug, Clone)]
pub enum VersionSubcommand {
	/// Switches the version of the editor in use.
	Use(UseVersionArgs),

	/// Shows the currently configured editor version.
	Show,
}

#[derive(Args, Debug, Clone)]
pub struct UseVersionArgs {
	/// The version of the editor you want to use. Can be "stable", "insiders",
	/// or an absolute path to an existing install.
	#[clap(value_name = "stable | insiders | x.y.z | path")]
	pub name: String,

	/// The directory where the version can be found.
	#[clap(long, value_name = "path")]
	pub install_dir: Option<String>,
}

#[derive(Args, Debug, Default, Clone)]
pub struct EditorOptions {
	/// Compare two files with each other.
	#[clap(short, long, value_names = &["file", "file"])]
	pub diff: Vec<String>,

	/// Add folder(s) to the last active window.
	#[clap(short, long, value_name = "folder")]
	pub add: Option<String>,

	/// Open a file at the path on the specified line and character position.
	#[clap(short, long, value_name = "file:line[:character]")]
	pub goto: Option<String>,

	/// Force to open a new window.
	#[clap(short, long)]
	pub new_window: bool,

	/// Force to open a file or folder in an
	#[clap(short, long)]
	pub reuse_window: bool,

	/// Wait for the files to be closed before returning.
	#[clap(short, long)]
	pub wait: bool,

	/// The locale to use (e.g. en-US or zh-TW).
	#[clap(long, value_name = "locale")]
	pub locale: Option<String>,

	/// Enables proposed API features for extensions. Can receive one or
	/// more extension IDs to enable individually.
	#[clap(long, value_name = "ext-id")]
	pub enable_proposed_api: Vec<String>,

	#[clap(flatten)]
	pub code_options: DesktopCodeOptions,
}

impl EditorOptions {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		if !self.diff.is_empty() {
			target.push("--diff".to_string());
			for file in self.diff.iter() {
				target.push(file.clone());
			}
		}
		if let Some(add) = &self.add {
			target.push("--add".to_string());
			target.push(add.clone());
		}
		if let Some(goto) = &self.goto {
			target.push("--goto".to_string());
			target.push(goto.clone());
		}
		if self.new_window {
			target.push("--new-window".to_string());
		}
		if self.reuse_window {
			target.push("--reuse-window".to_string());
		}
		if self.wait {
			target.push("--wait".to_string());
		}
		if let Some(locale) = &self.locale {
			target.push(format!("--locale={locale}"));
		}
		if !self.enable_proposed_api.is_empty() {
			for id in self.enable_proposed_api.iter() {
				target.push(format!("--enable-proposed-api={id}"));
			}
		}
		self.code_options.add_code_args(target);
	}
}

/// Arguments applicable whenever the desktop editor is launched
#[derive(Args, Debug, Default, Clone)]
pub struct DesktopCodeOptions {
	/// Set the root path for extensions.
	#[clap(long, value_name = "dir")]
	pub extensions_dir: Option<String>,

	/// Specifies the directory that user data is kept in. Can be used to
	/// open multiple distinct instances of the editor.
	#[clap(long, value_name = "dir")]
	pub user_data_dir: Option<String>,

	/// Sets the editor version to use for this command. The preferred version
	/// can be persisted with `code version use <version>`. Can be "stable",
	/// "insiders", a version number, or an absolute path to an existing install.
	#[clap(long, value_name = "stable | insiders | x.y.z | path")]
	pub use_version: Option<String>,
}

/// Argument specifying the output format.
#[derive(Args, Debug, Clone)]
pub struct OutputFormatOptions {
	/// Set the data output formats.
	#[clap(value_enum, long, value_name = "format", default_value_t = OutputFormat::Text)]
	pub format: OutputFormat,
}

impl DesktopCodeOptions {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		if let Some(extensions_dir) = &self.extensions_dir {
			target.push(format!("--extensions-dir={extensions_dir}"));
		}
		if let Some(user_data_dir) = &self.user_data_dir {
			target.push(format!("--user-data-dir={user_data_dir}"));
		}
	}
}

#[derive(Args, Debug, Default, Clone)]
pub struct GlobalOptions {
	/// Directory where CLI metadata should be stored.
	#[clap(long, env = "VSCODE_CLI_DATA_DIR", global = true)]
	pub cli_data_dir: Option<String>,

	/// Print verbose output (implies --wait).
	#[clap(long, global = true)]
	pub verbose: bool,

	/// Log to a file in addition to stdout. Used when running as a service.
	#[clap(long, global = true, hide = true)]
	pub log_to_file: Option<PathBuf>,

	/// Log level to use.
	#[clap(long, value_enum, value_name = "level", global = true)]
	pub log: Option<log::Level>,

	/// Disable telemetry for the current command, even if it was previously
	/// accepted as part of the license prompt or specified in '--telemetry-level'
	#[clap(long, global = true, hide = true)]
	pub disable_telemetry: bool,

	/// Sets the initial telemetry level
	#[clap(value_enum, long, global = true, hide = true)]
	pub telemetry_level: Option<options::TelemetryLevel>,
}

impl GlobalOptions {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		if self.verbose {
			target.push("--verbose".to_string());
		}
		if let Some(log) = self.log {
			target.push(format!("--log={log}"));
		}
		if self.disable_telemetry {
			target.push("--disable-telemetry".to_string());
		}
		if let Some(telemetry_level) = &self.telemetry_level {
			target.push(format!("--telemetry-level={telemetry_level}"));
		}
	}
}

#[derive(Args, Debug, Default, Clone)]
pub struct EditorTroubleshooting {
	/// Run CPU profiler during startup.
	#[clap(long)]
	pub prof_startup: bool,

	/// Disable all installed extensions.
	#[clap(long)]
	pub disable_extensions: bool,

	/// Disable an extension.
	#[clap(long, value_name = "ext-id")]
	pub disable_extension: Vec<String>,

	/// Turn sync on or off.
	#[clap(value_enum, long, value_name = "on | off")]
	pub sync: Option<SyncState>,

	/// Allow debugging and profiling of extensions. Check the developer tools for the connection URI.
	#[clap(long, value_name = "port")]
	pub inspect_extensions: Option<u16>,

	/// Allow debugging and profiling of extensions with the extension host
	/// being paused after start. Check the developer tools for the connection URI.
	#[clap(long, value_name = "port")]
	pub inspect_brk_extensions: Option<u16>,

	/// Disable GPU hardware acceleration.
	#[clap(long)]
	pub disable_gpu: bool,

	/// Shows all telemetry events which the editor collects.
	#[clap(long)]
	pub telemetry: bool,
}

impl EditorTroubleshooting {
	pub fn add_code_args(&self, target: &mut Vec<String>) {
		if self.prof_startup {
			target.push("--prof-startup".to_string());
		}
		if self.disable_extensions {
			target.push("--disable-extensions".to_string());
		}
		for id in self.disable_extension.iter() {
			target.push(format!("--disable-extension={id}"));
		}
		if let Some(sync) = &self.sync {
			target.push(format!("--sync={sync}"));
		}
		if let Some(port) = &self.inspect_extensions {
			target.push(format!("--inspect-extensions={port}"));
		}
		if let Some(port) = &self.inspect_brk_extensions {
			target.push(format!("--inspect-brk-extensions={port}"));
		}
		if self.disable_gpu {
			target.push("--disable-gpu".to_string());
		}
		if self.telemetry {
			target.push("--telemetry".to_string());
		}
	}
}

#[derive(ValueEnum, Clone, Copy, Debug)]
pub enum SyncState {
	On,
	Off,
}

impl fmt::Display for SyncState {
	fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
		match self {
			SyncState::Off => write!(f, "off"),
			SyncState::On => write!(f, "on"),
		}
	}
}

#[derive(ValueEnum, Clone, Copy, Debug)]
pub enum OutputFormat {
	Json,
	Text,
}

#[derive(Args, Clone, Debug, Default)]
pub struct ExistingTunnelArgs {
	/// Name you'd like to assign preexisting tunnel to use to connect the tunnel
	/// Old option, new code should just use `--name`.
	#[clap(long, hide = true)]
	pub tunnel_name: Option<String>,

	/// Token to authenticate and use preexisting tunnel
	#[clap(long, hide = true)]
	pub host_token: Option<String>,

	/// ID of preexisting tunnel to use to connect the tunnel
	#[clap(long, hide = true)]
	pub tunnel_id: Option<String>,

	/// Cluster of preexisting tunnel to use to connect the tunnel
	#[clap(long, hide = true)]
	pub cluster: Option<String>,
}

#[derive(Args, Debug, Clone, Default)]
pub struct TunnelServeArgs {
	#[clap(flatten)]
	pub server_args: BaseServerArgs,

	/// Optional details to connect to an existing tunnel
	#[clap(flatten, next_help_heading = Some("ADVANCED OPTIONS"))]
	pub tunnel: ExistingTunnelArgs,

	/// Randomly name machine for port forwarding service
	#[clap(long)]
	pub random_name: bool,

	/// Prevents the machine going to sleep while this command runs.
	#[clap(long)]
	pub no_sleep: bool,

	/// Sets the machine name for port forwarding service
	#[clap(long)]
	pub name: Option<String>,

	/// Optional parent process id. If provided, the server will be stopped when the process of the given pid no longer exists
	#[clap(long, hide = true)]
	pub parent_process_id: Option<String>,

	/// If set, the user accepts the server license terms and the server will be started without a user prompt.
	#[clap(long)]
	pub accept_server_license_terms: bool,

	/// Overrides the resolved user data directory used to home the local
	/// agent-host endpoint registry
	/// (`<user-data-dir>/agent-host/local-endpoint/entries/`, the directory of
	/// per-instance entry files editor windows also publish to). Defaults to
	/// the platform user data directory (honoring `VSCODE_PORTABLE` /
	/// `VSCODE_APPDATA` when set), matching the editor's own resolution rules.
	#[clap(long, hide = true)]
	pub user_data_dir: Option<String>,

	/// Emit machine-readable status lines on stdout for a parent process
	/// (the editor) to consume, in addition to the human-readable banner.
	#[clap(
		long,
		hide = true,
		env = "VSCODE_CLI_MACHINE_STATUS",
		action = clap::ArgAction::Set,
		num_args = 0..=1,
		default_value = "false",
		default_missing_value = "true",
		value_parser = clap::builder::BoolishValueParser::new()
	)]
	pub machine_status: bool,

	/// Serve only the editor's own agent host through this tunnel: the
	/// selection gateway pins every client to the live `editor` endpoint in
	/// the registry and refuses to start a dedicated agent host. Intended for
	/// tunnels whose lifetime is bound to the editor that started them, where
	/// a dedicated agent host would outlive the tunnel and be unreachable.
	#[clap(long, hide = true)]
	pub delegate_to_editor: bool,
}

#[derive(Args, Debug, Clone, Default)]
pub struct BaseServerArgs {
	/// Requests that extensions be preloaded and installed on connecting servers.
	#[clap(long)]
	pub install_extension: Vec<String>,

	/// Specifies the directory that server data is kept in.
	#[clap(long)]
	pub server_data_dir: Option<String>,

	/// Set the root path for extensions.
	#[clap(long)]
	pub extensions_dir: Option<String>,

	/// Reconnection grace time in seconds. Defaults to 10800 (3 hours).
	#[clap(long)]
	pub reconnection_grace_time: Option<u32>,
}

impl BaseServerArgs {
	pub fn apply_to(&self, csa: &mut CodeServerArgs) {
		csa.install_extensions
			.extend_from_slice(&self.install_extension);

		if let Some(d) = &self.server_data_dir {
			csa.server_data_dir = Some(d.clone());
		}

		if let Some(d) = &self.extensions_dir {
			csa.extensions_dir = Some(d.clone());
		}

		if let Some(t) = self.reconnection_grace_time {
			csa.reconnection_grace_time = Some(t);
		}
	}
}

#[derive(Args, Debug, Clone)]
pub struct TunnelArgs {
	#[clap(subcommand)]
	pub subcommand: Option<TunnelSubcommand>,

	#[clap(flatten)]
	pub serve_args: TunnelServeArgs,
}

#[derive(Subcommand, Debug, Clone)]
pub enum TunnelSubcommand {
	/// Delete all servers which are currently not running.
	Prune,

	/// Stops any running tunnel on the system.
	Kill,

	/// Restarts any running tunnel on the system.
	Restart,

	/// Gets whether there is a tunnel running on the current machine.
	Status,

	/// Rename the name of this machine associated with port forwarding service.
	Rename(TunnelRenameArgs),

	/// Remove this machine's association with the port forwarding service.
	Unregister,

	#[clap(subcommand)]
	User(TunnelUserSubCommands),

	/// (Preview) Manages the tunnel when installed as a system service,
	#[clap(subcommand)]
	Service(TunnelServiceSubCommands),

	/// (Preview) Forwards local port using the dev tunnel
	#[clap(hide = true)]
	ForwardInternal(TunnelForwardArgs),
}

#[derive(Subcommand, Debug, Clone)]
pub enum TunnelServiceSubCommands {
	/// Installs or re-installs the tunnel service on the machine.
	Install(TunnelServiceInstallArgs),

	/// Uninstalls and stops the tunnel service.
	Uninstall,

	/// Shows logs for the running service.
	Log,

	/// Internal command for running the service
	#[clap(hide = true)]
	InternalRun,
}

#[derive(Args, Debug, Clone)]
pub struct TunnelServiceInstallArgs {
	/// If set, the user accepts the server license terms and the server will be started without a user prompt.
	#[clap(long)]
	pub accept_server_license_terms: bool,

	/// Sets the machine name for port forwarding service
	#[clap(long)]
	pub name: Option<String>,
}

#[derive(Args, Debug, Clone)]
pub struct TunnelRenameArgs {
	/// The name you'd like to rename your machine to.
	pub name: String,
}

#[derive(Args, Debug, Clone)]
pub struct TunnelForwardArgs {
	/// One or more ports to forward.
	pub ports: Vec<u16>,

	/// Login args -- used for convenience so the forwarding call is a single action.
	#[clap(flatten)]
	pub login: LoginArgs,
}

#[derive(Subcommand, Debug, Clone)]
pub enum TunnelUserSubCommands {
	/// Log in to port forwarding service
	Login(LoginArgs),

	/// Log out of port forwarding service
	Logout,

	/// Show the account that's logged into port forwarding service
	Show,
}

#[derive(Args, Debug, Clone)]
pub struct LoginArgs {
	/// An access token to store for authentication.
	#[clap(long, requires = "provider", env = "VSCODE_CLI_ACCESS_TOKEN")]
	pub access_token: Option<String>,

	/// An access token to store for authentication.
	#[clap(long, requires = "access_token", env = "VSCODE_CLI_REFRESH_TOKEN")]
	pub refresh_token: Option<String>,

	/// The auth provider to use. If not provided, a prompt will be shown.
	#[clap(value_enum, long)]
	pub provider: Option<AuthProvider>,
}

#[derive(clap::ValueEnum, Debug, Clone, Copy)]
pub enum AuthProvider {
	Microsoft,
	Github,
}

#[cfg(test)]
mod tests {
	use super::{AgentHostArgs, AgentSubcommand, Commands, IntegratedCli, TunnelServeArgs};
	use clap::Parser;

	const MACHINE_STATUS_ENV: &str = "VSCODE_CLI_MACHINE_STATUS";

	fn parse_machine_status(args: &[&str]) -> bool {
		let cli = IntegratedCli::try_parse_from(args).unwrap();
		let Some(Commands::Tunnel(tunnel_args)) = cli.core.subcommand else {
			panic!("expected tunnel arguments");
		};

		tunnel_args.serve_args.machine_status
	}

	fn parse_agent_host_args(args: &[&str]) -> AgentHostArgs {
		let cli = IntegratedCli::try_parse_from(args).unwrap();
		let Some(Commands::Agent(args)) = cli.core.subcommand else {
			panic!("expected agent arguments");
		};
		match args.subcommand {
			Some(AgentSubcommand::Host(args)) => args,
			None => args.host_args,
			_ => panic!("expected agent host arguments"),
		}
	}

	#[test]
	fn agent_github_environment_accepts_remote_options() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			let mut argv = command;
			argv.extend([
				"--github-environment",
				"--name",
				"build-machine",
				"--github-environment-root",
				"project-a",
				"--github-environment-root",
				"project-b",
				"--user-data-dir",
				"profile",
				"--server-data-dir",
				"server-data",
				"--accept-server-license-terms",
			]);
			let args = parse_agent_host_args(&argv);
			assert_eq!(
				(
					args.github_environment,
					args.name.as_deref(),
					args.github_environment_root,
					args.accept_server_license_terms
				),
				(
					true,
					Some("build-machine"),
					vec!["project-a".into(), "project-b".into()],
					true
				)
			);
		}
	}

	#[test]
	fn agent_github_environment_rejects_incompatible_options() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			for options in [
				vec!["--tunnel"],
				vec!["--host", "0.0.0.0"],
				vec!["--port", "0"],
				vec!["--connection-token", "token"],
				vec!["--connection-token-file", "token"],
				vec!["--without-connection-token"],
				vec!["--replace"],
				vec!["--new-instance"],
				vec!["--foreground"],
				vec!["--idle-timeout", "300"],
				vec!["--random-name"],
				vec!["--tunnel-id", "id"],
				vec!["--host-token", "token"],
				vec!["--cluster", "cluster"],
				vec!["--tunnel-name", "name"],
			] {
				let mut argv = command.clone();
				argv.push("--github-environment");
				argv.extend(options);
				assert_eq!(
					IntegratedCli::try_parse_from(&argv).unwrap_err().kind(),
					clap::error::ErrorKind::ArgumentConflict,
					"{argv:?}"
				);
			}
		}
	}

	#[test]
	fn github_environment_options_require_hosting() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			let mut argv = command.clone();
			argv.extend(["--github-environment-root", "project"]);
			assert!(IntegratedCli::try_parse_from(&argv).is_err());
			let mut argv = command;
			argv.extend(["--tunnel", "--github-environment-root", "project"]);
			assert!(IntegratedCli::try_parse_from(&argv).is_err());
		}
	}

	#[test]
	fn github_environment_rejects_token_file_option() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			let mut argv = command;
			argv.extend([
				"--github-environment",
				"--github-environment-token-file",
				"token",
			]);
			assert_eq!(
				IntegratedCli::try_parse_from(&argv).unwrap_err().kind(),
				clap::error::ErrorKind::UnknownArgument,
				"{argv:?}"
			);
		}
	}

	#[test]
	fn agent_tunnel_alias_forwards_tunnel_options() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			let mut argv = command;
			argv.extend([
				"--tunnel",
				"--name",
				"my-machine",
				"--random-name",
				"--server-data-dir",
				"server-data",
				"--user-data-dir",
				"user-data",
				"--tunnel-id",
				"existing-id",
				"--host-token",
				"host-token",
				"--cluster",
				"cluster",
				"--tunnel-name",
				"existing-name",
				"--accept-server-license-terms",
			]);
			let args = parse_agent_host_args(&argv);
			assert!(args.tunnel);
			let args = TunnelServeArgs::from(args);
			assert_eq!(
				(
					args.name.as_deref(),
					args.random_name,
					args.server_args.server_data_dir.as_deref(),
					args.user_data_dir.as_deref(),
					args.tunnel.tunnel_id.as_deref(),
					args.tunnel.host_token.as_deref(),
					args.tunnel.cluster.as_deref(),
					args.tunnel.tunnel_name.as_deref(),
					args.accept_server_license_terms,
					args.delegate_to_editor,
				),
				(
					Some("my-machine"),
					true,
					Some("server-data"),
					Some("user-data"),
					Some("existing-id"),
					Some("host-token"),
					Some("cluster"),
					Some("existing-name"),
					true,
					false,
				)
			);
		}
	}

	#[test]
	fn agent_tunnel_alias_rejects_local_host_options() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			for options in [
				vec!["--host", "0.0.0.0"],
				vec!["--port", "0"],
				vec!["--connection-token", "token"],
				vec!["--connection-token-file", "token-file"],
				vec!["--without-connection-token"],
				vec!["--replace"],
				vec!["--new-instance"],
				vec!["--foreground"],
				vec!["--idle-timeout", "300"],
			] {
				let mut argv = command.clone();
				argv.push("--tunnel");
				argv.extend(options);
				assert_eq!(
					IntegratedCli::try_parse_from(&argv).unwrap_err().kind(),
					clap::error::ErrorKind::ArgumentConflict,
					"{argv:?}"
				);
			}
		}
	}

	#[test]
	fn agent_host_without_tunnel_still_accepts_local_options() {
		for command in [vec!["code", "agent"], vec!["code", "agent", "host"]] {
			let mut argv = command;
			argv.extend([
				"--host",
				"0.0.0.0",
				"--port",
				"1234",
				"--connection-token",
				"token",
				"--replace",
				"--new-instance",
				"--foreground",
				"--idle-timeout",
				"300",
			]);
			let args = parse_agent_host_args(&argv);
			assert_eq!(
				(
					args.tunnel,
					args.host.as_deref(),
					args.port,
					args.connection_token.as_deref(),
					args.replace,
					args.new_instance,
					args.foreground,
					args.idle_timeout,
				),
				(
					false,
					Some("0.0.0.0"),
					1234,
					Some("token"),
					true,
					true,
					true,
					Some(300)
				)
			);
		}
	}

	#[test]
	fn tunnel_rejects_agent_host_only_mode() {
		assert_eq!(
			IntegratedCli::try_parse_from(["code", "tunnel", "--agent-host-only"])
				.unwrap_err()
				.kind(),
			clap::error::ErrorKind::UnknownArgument
		);
	}

	/// Mutates process-global environment, which `cargo test` runs in parallel
	/// with every other test. This is only safe because no other test reads
	/// `VSCODE_CLI_MACHINE_STATUS`; if a second env-dependent test is added
	/// here, serialize them (a shared mutex) rather than letting them race.
	#[test]
	fn parses_machine_status_from_flag_and_environment() {
		let previous_value = std::env::var_os(MACHINE_STATUS_ENV);
		std::env::remove_var(MACHINE_STATUS_ENV);

		assert!(!parse_machine_status(&["code", "tunnel"]));

		std::env::set_var(MACHINE_STATUS_ENV, "1");
		assert!(parse_machine_status(&["code", "tunnel"]));

		std::env::set_var(MACHINE_STATUS_ENV, "0");
		assert!(!parse_machine_status(&["code", "tunnel"]));

		std::env::set_var(MACHINE_STATUS_ENV, "false");
		assert!(!parse_machine_status(&["code", "tunnel"]));

		std::env::remove_var(MACHINE_STATUS_ENV);
		assert!(parse_machine_status(&[
			"code",
			"tunnel",
			"--machine-status"
		]));

		match previous_value {
			Some(value) => std::env::set_var(MACHINE_STATUS_ENV, value),
			None => std::env::remove_var(MACHINE_STATUS_ENV),
		}
	}
}
